<?php
 // created: 2024-05-18 00:13:44
$dictionary['Case']['fields']['advocase_case_other_issue_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_case_other_issue_c']['labelValue']='Other issue';

 ?>