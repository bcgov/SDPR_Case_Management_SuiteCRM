<?php
 // created: 2024-05-31 19:10:30
$dictionary['Meeting']['fields']['description']['inline_edit']=true;
$dictionary['Meeting']['fields']['description']['comments']='Full text of the note';
$dictionary['Meeting']['fields']['description']['merge_filter']='disabled';

 ?>