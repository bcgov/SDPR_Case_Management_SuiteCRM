<?php
 // created: 2024-05-21 18:43:32
$dictionary['Call']['fields']['description']['required']=true;
$dictionary['Call']['fields']['description']['inline_edit']=true;
$dictionary['Call']['fields']['description']['comments']='Full text of the note';
$dictionary['Call']['fields']['description']['merge_filter']='disabled';

 ?>