<?php
 // created: 2024-05-16 22:45:23
$dictionary['Account']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>