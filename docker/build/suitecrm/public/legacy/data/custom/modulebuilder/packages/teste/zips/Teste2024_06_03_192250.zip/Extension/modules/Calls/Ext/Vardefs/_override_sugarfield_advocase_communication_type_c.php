<?php
 // created: 2024-05-21 18:42:08
$dictionary['Call']['fields']['advocase_communication_type_c']['inline_edit']='1';
$dictionary['Call']['fields']['advocase_communication_type_c']['labelValue']='Type of Communication';

 ?>