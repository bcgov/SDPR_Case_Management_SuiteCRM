<?php
 // created: 2024-05-17 19:58:20
$dictionary['Contact']['fields']['advocase_other_contact_type_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_other_contact_type_c']['labelValue']='Other';

 ?>