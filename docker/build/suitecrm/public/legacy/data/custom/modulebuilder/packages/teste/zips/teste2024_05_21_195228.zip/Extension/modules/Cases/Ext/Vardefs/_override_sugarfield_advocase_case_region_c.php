<?php
 // created: 2024-05-18 00:02:35
$dictionary['Case']['fields']['advocase_case_region_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_case_region_c']['labelValue']='Region of Case';

 ?>