<?php
// created: 2024-05-29 18:02:18
$mod_strings['LBL_ADVOCASE_COMMUNICATION_OTHER'] = 'Other Type of Communication';
$mod_strings['LBL_ADVOCASE_COMMUNICATION_TYPE'] = 'Type of Communication';
$mod_strings['LBL_DATE_ENTERED'] = 'Date Entered';
$mod_strings['LBL_DESCRIPTION'] = 'Communication Notes';
$mod_strings['LBL_ADVOCASE_ASQ_ASSESSMENT'] = 'ASQ Assessment for Need';
$mod_strings['LBL_ADVOCASE_ADVOCATE_KOWNLEDGE'] = 'How heard of Advocate';
$mod_strings['LBL_LIST_RELATED_TO'] = 'Contact ID';
$mod_strings['LBL_ADVOCASE_COMMUNICATION_DATE'] = 'Date of Communication';
