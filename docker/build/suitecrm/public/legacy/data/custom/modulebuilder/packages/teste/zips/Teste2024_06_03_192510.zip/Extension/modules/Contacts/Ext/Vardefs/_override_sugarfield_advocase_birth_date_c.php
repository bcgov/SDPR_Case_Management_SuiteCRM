<?php
 // created: 2024-05-17 20:17:11
$dictionary['Contact']['fields']['advocase_birth_date_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_birth_date_c']['labelValue']='Individual Birth Date';

 ?>