<?php
 // created: 2024-05-18 00:26:38
$dictionary['Case']['fields']['adovcase_case_agencies_c']['inline_edit']='1';
$dictionary['Case']['fields']['adovcase_case_agencies_c']['labelValue']='Other Agencies engaged';

 ?>