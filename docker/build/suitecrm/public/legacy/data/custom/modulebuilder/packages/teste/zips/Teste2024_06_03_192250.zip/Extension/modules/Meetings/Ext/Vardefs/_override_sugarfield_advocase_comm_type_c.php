<?php
 // created: 2024-05-31 19:03:57
$dictionary['Meeting']['fields']['advocase_comm_type_c']['inline_edit']='1';
$dictionary['Meeting']['fields']['advocase_comm_type_c']['labelValue']='Type of Communication';

 ?>