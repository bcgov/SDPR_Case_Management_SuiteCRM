<?php
// created: 2024-05-18 00:32:59
$mod_strings['LBL_ADVOCASE_COMMUNICATION_DATE'] = 'Date of Communication';
$mod_strings['LBL_ADVOCASE_COMMUNICATION_TYPE'] = 'Type of Communication';
$mod_strings['LBL_ADVOCASE_OTHER_COMM_TYPE'] = 'Other Communication';
$mod_strings['LBL_ADVOCASE_ASQ_ACTION'] = 'ASQ Action';
$mod_strings['LBL_ADVOCASE_CALL_LOG'] = 'Call Log';
$mod_strings['LBL_ADVOCASE_OASQ_AWARENESS'] = 'How did the contact hear about the OASQ?';
$mod_strings['LBL_ADVOCASE_CASE_CITY'] = 'City for Case';
$mod_strings['LBL_ADVOCASE_CASE_REGION'] = 'Region of Case';
$mod_strings['LBL_ADVOCASE_CASE_ISSUES'] = 'Issue(s)';
$mod_strings['LBL_ADVOCASE_CASE_OTHER_ISSUE'] = 'Other issue';
$mod_strings['LBL_ADOVCASE_CASE_AGENCIES'] = 'Other Agencies engaged';
$mod_strings['LBL_ADVOCASE_CASE_OTHER_NONE'] = 'Other/None';
$mod_strings['LBL_ADVOCASE_CASE_ACTION_DATE'] = 'Action Taken date';
