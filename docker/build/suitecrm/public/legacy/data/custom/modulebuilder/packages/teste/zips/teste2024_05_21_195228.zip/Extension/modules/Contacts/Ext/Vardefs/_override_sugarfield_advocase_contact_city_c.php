<?php
 // created: 2024-05-17 00:43:09
$dictionary['Contact']['fields']['advocase_contact_city_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_contact_city_c']['labelValue']='Contact City';

 ?>