<?php
 // created: 2024-05-17 23:42:31
$dictionary['Case']['fields']['advocase_communication_type_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_communication_type_c']['labelValue']='Type of Communication';

 ?>