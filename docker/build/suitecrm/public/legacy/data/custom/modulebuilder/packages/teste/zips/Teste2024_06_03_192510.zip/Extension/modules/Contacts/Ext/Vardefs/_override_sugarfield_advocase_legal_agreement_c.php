<?php
 // created: 2024-05-17 00:42:25
$dictionary['Contact']['fields']['advocase_legal_agreement_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_legal_agreement_c']['labelValue']='Legal Agreement in Place';

 ?>