<?php
 // created: 2024-05-17 20:05:21
$dictionary['Contact']['fields']['advocase_contact_type_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_contact_type_c']['labelValue']='Type of Contact';

 ?>