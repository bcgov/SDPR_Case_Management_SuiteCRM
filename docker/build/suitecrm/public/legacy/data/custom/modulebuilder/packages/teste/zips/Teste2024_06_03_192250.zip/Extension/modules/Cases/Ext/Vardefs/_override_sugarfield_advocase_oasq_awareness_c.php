<?php
 // created: 2024-05-17 23:56:41
$dictionary['Case']['fields']['advocase_oasq_awareness_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_oasq_awareness_c']['labelValue']='How did the contact hear about the OASQ?';

 ?>