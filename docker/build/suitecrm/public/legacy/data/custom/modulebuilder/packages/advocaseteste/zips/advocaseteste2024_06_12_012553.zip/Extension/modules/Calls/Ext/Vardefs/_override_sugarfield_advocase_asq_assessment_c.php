<?php
 // created: 2024-05-28 23:19:22
$dictionary['Call']['fields']['advocase_asq_assessment_c']['inline_edit']='1';
$dictionary['Call']['fields']['advocase_asq_assessment_c']['labelValue']='ASQ Assessment for Need';

 ?>