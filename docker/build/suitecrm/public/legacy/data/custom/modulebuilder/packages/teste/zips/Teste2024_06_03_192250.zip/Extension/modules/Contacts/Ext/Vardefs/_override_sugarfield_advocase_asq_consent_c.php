<?php
 // created: 2024-05-17 00:35:30
$dictionary['Contact']['fields']['advocase_asq_consent_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_asq_consent_c']['labelValue']='Consent for ASQ action';

 ?>