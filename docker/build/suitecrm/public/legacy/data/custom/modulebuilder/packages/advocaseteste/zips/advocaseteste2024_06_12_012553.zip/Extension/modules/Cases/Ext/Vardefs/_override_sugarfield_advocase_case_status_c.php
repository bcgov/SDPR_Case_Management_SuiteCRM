<?php
 // created: 2024-06-01 00:51:31
$dictionary['Case']['fields']['advocase_case_status_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_case_status_c']['labelValue']='Status';

 ?>