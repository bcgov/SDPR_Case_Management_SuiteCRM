<?php
 // created: 2024-05-18 00:27:48
$dictionary['Case']['fields']['advocase_case_action_date_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_case_action_date_c']['labelValue']='Action Taken date';

 ?>