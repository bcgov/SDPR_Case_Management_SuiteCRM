<?php
// created: 2024-05-24 16:45:40
$mod_strings['LBL_ADVOCASE_DATE_RANGE'] = 'Time period';
$mod_strings['LBL_ADVOCASE_DATE_FROM'] = 'Start date';
