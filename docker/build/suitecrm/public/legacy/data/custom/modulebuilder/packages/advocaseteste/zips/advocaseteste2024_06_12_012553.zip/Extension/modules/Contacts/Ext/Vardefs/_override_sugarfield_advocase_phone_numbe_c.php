<?php
 // created: 2024-05-17 00:34:09
$dictionary['Contact']['fields']['advocase_phone_numbe_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_phone_numbe_c']['labelValue']='Phone number';

 ?>