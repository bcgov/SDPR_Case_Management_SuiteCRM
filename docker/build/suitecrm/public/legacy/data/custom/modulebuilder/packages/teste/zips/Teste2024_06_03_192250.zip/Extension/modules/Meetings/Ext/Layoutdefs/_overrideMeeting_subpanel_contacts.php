<?php
//auto-generated file DO NOT EDIT
$layout_defs['Meetings']['subpanel_setup']['contacts']['override_subpanel_name'] = 'Meeting_subpanel_contacts';
?>