<?php
 // created: 2024-05-21 18:40:27
$dictionary['Call']['fields']['advocase_communication_other_c']['inline_edit']='1';
$dictionary['Call']['fields']['advocase_communication_other_c']['labelValue']='Other Type of Communication';

 ?>