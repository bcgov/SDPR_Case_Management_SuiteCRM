<?php
 // created: 2024-05-17 00:47:22
$dictionary['Contact']['fields']['advocase_contact_region_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_contact_region_c']['labelValue']='Contact Region';

 ?>