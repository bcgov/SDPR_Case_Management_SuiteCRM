<?php
 // created: 2024-05-21 18:54:02
$dictionary['Call']['fields']['advocase_advocate_kownledge_c']['inline_edit']='1';
$dictionary['Call']['fields']['advocase_advocate_kownledge_c']['labelValue']='How heard of Advocate';

 ?>