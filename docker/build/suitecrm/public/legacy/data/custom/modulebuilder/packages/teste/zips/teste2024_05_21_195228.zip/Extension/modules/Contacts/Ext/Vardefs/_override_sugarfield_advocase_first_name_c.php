<?php
 // created: 2024-05-17 00:27:21
$dictionary['Contact']['fields']['advocase_first_name_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_first_name_c']['labelValue']='First Name';

 ?>