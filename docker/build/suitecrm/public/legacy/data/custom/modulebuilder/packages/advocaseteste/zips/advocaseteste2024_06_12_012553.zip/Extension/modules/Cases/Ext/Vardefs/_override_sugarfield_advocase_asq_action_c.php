<?php
 // created: 2024-05-17 23:45:00
$dictionary['Case']['fields']['advocase_asq_action_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_asq_action_c']['labelValue']='ASQ Action';

 ?>