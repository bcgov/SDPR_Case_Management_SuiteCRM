<?php
//auto-generated file DO NOT EDIT
$layout_defs['Cases']['subpanel_setup']['contacts']['override_subpanel_name'] = 'Case_subpanel_contacts';
?>