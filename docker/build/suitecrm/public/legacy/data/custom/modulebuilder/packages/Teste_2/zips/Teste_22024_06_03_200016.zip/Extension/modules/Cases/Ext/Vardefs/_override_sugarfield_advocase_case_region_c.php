<?php
 // created: 2024-05-28 22:00:08
$dictionary['Case']['fields']['advocase_case_region_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_case_region_c']['labelValue']='Region of Case';

 ?>