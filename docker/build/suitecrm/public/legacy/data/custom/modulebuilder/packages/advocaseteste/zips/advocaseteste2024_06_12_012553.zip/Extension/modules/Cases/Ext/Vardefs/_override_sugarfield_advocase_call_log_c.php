<?php
 // created: 2024-05-17 23:46:08
$dictionary['Case']['fields']['advocase_call_log_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_call_log_c']['labelValue']='Call Log';

 ?>