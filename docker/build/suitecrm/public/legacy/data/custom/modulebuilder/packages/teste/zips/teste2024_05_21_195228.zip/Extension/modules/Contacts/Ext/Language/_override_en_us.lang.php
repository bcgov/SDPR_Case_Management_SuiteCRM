<?php
// created: 2024-05-17 20:17:54
$mod_strings['LBL_ADVOCASE_CONTACT_TYPE'] = 'Type of Contact';
$mod_strings['LBL_ADVOCASE_LAST_NAME'] = 'Last Name';
$mod_strings['LBL_ADVOCASE_FIRST_NAME'] = 'First Name';
$mod_strings['LBL_ADVOCASE_EMAIL'] = 'Email';
$mod_strings['LBL_ADVOCASE_PHONE_NUMBE'] = 'Phone number';
$mod_strings['LBL_ADVOCASE_SEC_PHONE_NUMBER'] = 'Secondary Phone Number';
$mod_strings['LBL_ADVOCASE_ASQ_CONSENT'] = 'Consent for ASQ action';
$mod_strings['LBL_ADVOCASE_LEGAL_AGREEMENT'] = 'Legal Agreement in Place';
$mod_strings['LBL_ADVOCASE_CONTACT_CITY'] = 'Contact City';
$mod_strings['LBL_ADVOCASE_CONTACT_REGION'] = 'Contact Region';
$mod_strings['LBL_ADVOCASE_NOTES'] = 'Notes';
$mod_strings['LBL_ADVOCASE_BIRTH_DATE'] = 'Individual Birth Date';
$mod_strings['LBL_ADVOCASE_INDIVIDUAL_AGE'] = 'Age Range of Individual';
$mod_strings['LBL_ADVOCASE_CLBL_ELIGIBLE'] = 'CLBC Eligible?';
$mod_strings['LBL_ADVOCASE_GSA_LEVEL'] = 'Individual Level of GSA';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'New Panel 3';
$mod_strings['LBL_ADVOCASE_OTHER_CONTACT_TYPE'] = 'Other';
