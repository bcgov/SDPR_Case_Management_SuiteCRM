<?php
 // created: 2024-05-31 19:01:24
$dictionary['Meeting']['fields']['advocase_case_id_c']['inline_edit']='1';
$dictionary['Meeting']['fields']['advocase_case_id_c']['labelValue']='Case ID';

 ?>