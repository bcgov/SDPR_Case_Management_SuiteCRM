<?php
// created: 2024-05-31 18:53:47
$mod_strings['LBL_MEETINGS'] = 'Communications';
