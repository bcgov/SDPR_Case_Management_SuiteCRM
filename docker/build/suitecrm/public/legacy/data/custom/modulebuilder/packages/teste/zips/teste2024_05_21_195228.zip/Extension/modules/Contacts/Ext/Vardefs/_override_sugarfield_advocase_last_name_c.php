<?php
 // created: 2024-05-17 20:10:47
$dictionary['Contact']['fields']['advocase_last_name_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_last_name_c']['labelValue']='Last Name';

 ?>