<?php
 // created: 2024-05-17 23:59:03
$dictionary['Case']['fields']['advocase_case_city_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_case_city_c']['labelValue']='City for Case';

 ?>