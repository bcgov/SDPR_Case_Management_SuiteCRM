<?php
$viewdefs ['Contacts'] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          'SEND_CONFIRM_OPT_IN_EMAIL' => 
          array (
            'customCode' => '<input type="submit" class="button hidden" disabled="disabled" title="{$APP.LBL_SEND_CONFIRM_OPT_IN_EMAIL}" onclick="this.form.return_module.value=\'Contacts\'; this.form.return_action.value=\'Contacts\'; this.form.return_id.value=\'{$fields.id.value}\'; this.form.action.value=\'sendConfirmOptInEmail\'; this.form.module.value=\'Contacts\'; this.form.module_tab.value=\'Contacts\';" name="send_confirm_opt_in_email" value="{$APP.LBL_SEND_CONFIRM_OPT_IN_EMAIL}"/>',
            'sugar_html' => 
            array (
              'type' => 'submit',
              'value' => '{$APP.LBL_SEND_CONFIRM_OPT_IN_EMAIL}',
              'htmlOptions' => 
              array (
                'class' => 'button hidden',
                'id' => 'send_confirm_opt_in_email',
                'title' => '{$APP.LBL_SEND_CONFIRM_OPT_IN_EMAIL}',
                'onclick' => 'this.form.return_module.value=\'Contacts\'; this.form.return_action.value=\'DetailView\'; this.form.return_id.value=\'{$fields.id.value}\'; this.form.action.value=\'sendConfirmOptInEmail\'; this.form.module.value=\'Contacts\'; this.form.module_tab.value=\'Contacts\';',
                'name' => 'send_confirm_opt_in_email',
                'disabled' => true,
              ),
            ),
          ),
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
          4 => 
          array (
            'customCode' => '<input type="submit" class="button" title="{$APP.LBL_MANAGE_SUBSCRIPTIONS}" onclick="this.form.return_module.value=\'Contacts\'; this.form.return_action.value=\'DetailView\'; this.form.return_id.value=\'{$fields.id.value}\'; this.form.action.value=\'Subscriptions\'; this.form.module.value=\'Campaigns\'; this.form.module_tab.value=\'Contacts\';" name="Manage Subscriptions" value="{$APP.LBL_MANAGE_SUBSCRIPTIONS}"/>',
            'sugar_html' => 
            array (
              'type' => 'submit',
              'value' => '{$APP.LBL_MANAGE_SUBSCRIPTIONS}',
              'htmlOptions' => 
              array (
                'class' => 'button',
                'id' => 'manage_subscriptions_button',
                'title' => '{$APP.LBL_MANAGE_SUBSCRIPTIONS}',
                'onclick' => 'this.form.return_module.value=\'Contacts\'; this.form.return_action.value=\'DetailView\'; this.form.return_id.value=\'{$fields.id.value}\'; this.form.action.value=\'Subscriptions\'; this.form.module.value=\'Campaigns\'; this.form.module_tab.value=\'Contacts\';',
                'name' => 'Manage Subscriptions',
              ),
            ),
          ),
          'AOS_GENLET' => 
          array (
            'customCode' => '<input type="button" class="button" onClick="showPopup();" value="{$APP.LBL_PRINT_AS_PDF}">',
          ),
          'AOP_CREATE' => 
          array (
            'customCode' => '{if !$fields.joomla_account_id.value && $AOP_PORTAL_ENABLED}<input type="submit" class="button" onClick="this.form.action.value=\'createPortalUser\';" value="{$MOD.LBL_CREATE_PORTAL_USER}"> {/if}',
            'sugar_html' => 
            array (
              'type' => 'submit',
              'value' => '{$MOD.LBL_CREATE_PORTAL_USER}',
              'htmlOptions' => 
              array (
                'title' => '{$MOD.LBL_CREATE_PORTAL_USER}',
                'class' => 'button',
                'onclick' => 'this.form.action.value=\'createPortalUser\';',
                'name' => 'buttonCreatePortalUser',
                'id' => 'createPortalUser_button',
              ),
              'template' => '{if !$fields.joomla_account_id.value && $AOP_PORTAL_ENABLED}[CONTENT]{/if}',
            ),
          ),
          'AOP_DISABLE' => 
          array (
            'customCode' => '{if $fields.joomla_account_id.value && !$fields.portal_account_disabled.value && $AOP_PORTAL_ENABLED}<input type="submit" class="button" onClick="this.form.action.value=\'disablePortalUser\';" value="{$MOD.LBL_DISABLE_PORTAL_USER}"> {/if}',
            'sugar_html' => 
            array (
              'type' => 'submit',
              'value' => '{$MOD.LBL_DISABLE_PORTAL_USER}',
              'htmlOptions' => 
              array (
                'title' => '{$MOD.LBL_DISABLE_PORTAL_USER}',
                'class' => 'button',
                'onclick' => 'this.form.action.value=\'disablePortalUser\';',
                'name' => 'buttonDisablePortalUser',
                'id' => 'disablePortalUser_button',
              ),
              'template' => '{if $fields.joomla_account_id.value && !$fields.portal_account_disabled.value && $AOP_PORTAL_ENABLED}[CONTENT]{/if}',
            ),
          ),
          'AOP_ENABLE' => 
          array (
            'customCode' => '{if $fields.joomla_account_id.value && $fields.portal_account_disabled.value && $AOP_PORTAL_ENABLED}<input type="submit" class="button" onClick="this.form.action.value=\'enablePortalUser\';" value="{$MOD.LBL_ENABLE_PORTAL_USER}"> {/if}',
            'sugar_html' => 
            array (
              'type' => 'submit',
              'value' => '{$MOD.LBL_ENABLE_PORTAL_USER}',
              'htmlOptions' => 
              array (
                'title' => '{$MOD.LBL_ENABLE_PORTAL_USER}',
                'class' => 'button',
                'onclick' => 'this.form.action.value=\'enablePortalUser\';',
                'name' => 'buttonENablePortalUser',
                'id' => 'enablePortalUser_button',
              ),
              'template' => '{if $fields.joomla_account_id.value && $fields.portal_account_disabled.value && $AOP_PORTAL_ENABLED}[CONTENT]{/if}',
            ),
          ),
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'includes' => 
      array (
        0 => 
        array (
          'file' => 'modules/Contacts/Contact.js',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_CONTACT_INFORMATION' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'summaryTemplates' => 
    array (
      'edit' => 'LBL_SUMMARY_PERSON',
      'detail' => 'LBL_SUMMARY_PERSON',
    ),
    'topWidget' => 
    array (
      'type' => 'statistics',
      'options' => 
      array (
        'statistics' => 
        array (
          0 => 
          array (
            'labelKey' => '',
            'type' => 'contact-last-touchpoint',
            'hideValueIfEmpty' => true,
          ),
        ),
      ),
      'acls' => 
      array (
        'Contacts' => 
        array (
          0 => 'view',
          1 => 'list',
        ),
      ),
    ),
    'sidebarWidgets' => 
    array (
      0 => 
      array (
        'type' => 'history-timeline',
        'acls' => 
        array (
          'Contacts' => 
          array (
            0 => 'view',
            1 => 'list',
          ),
        ),
      ),
    ),
    'recordActions' => 
    array (
      'actions' => 
      array (
        'print-as-pdf' => 
        array (
          'key' => 'print-as-pdf',
          'labelKey' => 'LBL_PRINT_AS_PDF',
          'asyncProcess' => true,
          'modes' => 
          array (
            0 => 'detail',
          ),
          'acl' => 
          array (
            0 => 'view',
          ),
          'aclModule' => 'AOS_PDF_Templates',
          'params' => 
          array (
            'selectModal' => 
            array (
              'module' => 'AOS_PDF_Templates',
            ),
          ),
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_contact_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'advocase_contact_type_c',
            'studio' => 'visible',
            'label' => 'LBL_ADVOCASE_CONTACT_TYPE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'advocase_other_contact_type_c',
            'label' => 'LBL_ADVOCASE_OTHER_CONTACT_TYPE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'last_name',
            'comment' => 'Last name of the contact',
            'label' => 'LBL_LAST_NAME',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'first_name',
            'comment' => 'First name of the contact',
            'label' => 'LBL_FIRST_NAME',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'advocase_email_c',
            'label' => 'LBL_ADVOCASE_EMAIL',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'advocase_phone_numbe_c',
            'label' => 'LBL_ADVOCASE_PHONE_NUMBE',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'advocase_sec_phone_number_c',
            'label' => 'LBL_ADVOCASE_SEC_PHONE_NUMBER',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'advocase_asq_consent_c',
            'label' => 'LBL_ADVOCASE_ASQ_CONSENT',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'advocase_legal_agreement_c',
            'studio' => 'visible',
            'label' => 'LBL_ADVOCASE_LEGAL_AGREEMENT',
          ),
        ),
        9 => 
        array (
          0 => 
          array (
            'name' => 'advocase_contact_city_c',
            'label' => 'LBL_ADVOCASE_CONTACT_CITY',
          ),
        ),
        10 => 
        array (
          0 => 
          array (
            'name' => 'advocase_contact_region_c',
            'studio' => 'visible',
            'label' => 'LBL_ADVOCASE_CONTACT_REGION',
          ),
        ),
        11 => 
        array (
          0 => 
          array (
            'name' => 'advocase_notes_c',
            'studio' => 'visible',
            'label' => 'LBL_ADVOCASE_NOTES',
          ),
        ),
        12 => 
        array (
          0 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
        13 => 
        array (
          0 => 
          array (
            'name' => 'advocase_birth_date_c',
            'label' => 'LBL_ADVOCASE_BIRTH_DATE',
          ),
        ),
        14 => 
        array (
          0 => 
          array (
            'name' => 'advocase_individual_age_c',
            'studio' => 'visible',
            'label' => 'LBL_ADVOCASE_INDIVIDUAL_AGE',
          ),
        ),
        15 => 
        array (
          0 => 
          array (
            'name' => 'advocase_clbl_eligible_c',
            'studio' => 'visible',
            'label' => 'LBL_ADVOCASE_CLBL_ELIGIBLE',
          ),
        ),
        16 => 
        array (
          0 => 
          array (
            'name' => 'advocase_gsa_level_c',
            'studio' => 'visible',
            'label' => 'LBL_ADVOCASE_GSA_LEVEL',
          ),
        ),
      ),
    ),
  ),
);
;
?>
