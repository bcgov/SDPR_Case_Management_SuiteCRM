<?php
 // created: 2024-05-17 00:49:22
$dictionary['Contact']['fields']['advocase_notes_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_notes_c']['labelValue']='Notes';

 ?>