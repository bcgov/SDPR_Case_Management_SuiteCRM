<?php
 // created: 2024-05-17 23:39:39
$dictionary['Case']['fields']['advocase_communication_date_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_communication_date_c']['labelValue']='Date of Communication';

 ?>