<?php
 // created: 2024-05-16 22:45:24
$dictionary['Opportunity']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>