<?php
 // created: 2024-05-17 23:42:15
$dictionary['Case']['fields']['advocase_other_comm_type_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_other_comm_type_c']['labelValue']='Other';

 ?>