<?php
 // created: 2024-05-31 19:03:01
$dictionary['Meeting']['fields']['advocase_comm_date_c']['inline_edit']='1';
$dictionary['Meeting']['fields']['advocase_comm_date_c']['labelValue']='Date of Communication';

 ?>