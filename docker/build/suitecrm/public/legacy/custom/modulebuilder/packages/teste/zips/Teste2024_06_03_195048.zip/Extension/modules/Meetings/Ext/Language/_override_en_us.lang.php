<?php
// created: 2024-05-31 19:28:22
$mod_strings['LNK_NEW_MEETING'] = 'Schedule Communication';
$mod_strings['LNK_MEETING_LIST'] = 'View Communications';
$mod_strings['LNK_IMPORT_MEETINGS'] = 'Import Communications';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Communication List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Communication Search';
$mod_strings['LBL_LIST_MY_MEETINGS'] = 'My Communications';
$mod_strings['LBL_LIST_JOIN_MEETING'] = 'Join Communication';
$mod_strings['LBL_PASSWORD'] = 'Communication Password';
$mod_strings['LBL_TYPE'] = 'Communication Type';
$mod_strings['LBL_URL'] = 'Start/Join Communication';
$mod_strings['LBL_MODULE_NAME'] = 'Communications';
$mod_strings['LBL_ADVOCASE_CASE_ID_ACASE_ID'] = 'Case ID (related Case ID)';
$mod_strings['LBL_ADVOCASE_CASE_ID'] = 'Case ID';
$mod_strings['LBL_ADVOCASE_COMM_DATE'] = 'Date of Communication';
$mod_strings['LBL_ADVOCASE_COMM_TYPE'] = 'Type of Communication';
$mod_strings['LBL_ADVOCASE_OTHER_COMM'] = 'Other type';
$mod_strings['LBL_DESCRIPTION'] = 'Communication Notes';
$mod_strings['LBL_CONTACTS_SUBPANEL_TITLE'] = 'Contacts';
