<?php
 // created: 2024-05-31 19:01:24
$dictionary['Meeting']['fields']['acase_id_c']['inline_edit']=1;

 ?>