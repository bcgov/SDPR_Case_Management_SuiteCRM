<?php
 // created: 2024-05-24 16:45:40
$dictionary['AOR_Report']['fields']['advocase_date_from_c']['inline_edit']='1';
$dictionary['AOR_Report']['fields']['advocase_date_from_c']['labelValue']='Start date';

 ?>