<?php
// created: 2024-05-31 18:53:48
$mod_strings['LBL_MEETINGS'] = 'Communications';
