<?php
 // created: 2024-05-17 00:28:07
$dictionary['Contact']['fields']['advocase_email_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_email_c']['labelValue']='Email';

 ?>