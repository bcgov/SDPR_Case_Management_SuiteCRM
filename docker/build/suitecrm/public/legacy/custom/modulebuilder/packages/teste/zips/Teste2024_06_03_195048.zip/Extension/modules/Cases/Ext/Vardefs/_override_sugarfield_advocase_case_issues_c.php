<?php
 // created: 2024-05-18 00:13:54
$dictionary['Case']['fields']['advocase_case_issues_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_case_issues_c']['labelValue']='Issue(s)';

 ?>