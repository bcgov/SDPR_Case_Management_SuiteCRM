<?php
 // created: 2024-05-17 00:53:41
$dictionary['Contact']['fields']['advocase_clbl_eligible_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_clbl_eligible_c']['labelValue']='CLBC Eligible?';

 ?>