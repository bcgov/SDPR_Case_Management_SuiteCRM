<?php
 // created: 2024-05-17 00:34:39
$dictionary['Contact']['fields']['advocase_sec_phone_number_c']['inline_edit']='1';
$dictionary['Contact']['fields']['advocase_sec_phone_number_c']['labelValue']='Secondary Phone Number';

 ?>