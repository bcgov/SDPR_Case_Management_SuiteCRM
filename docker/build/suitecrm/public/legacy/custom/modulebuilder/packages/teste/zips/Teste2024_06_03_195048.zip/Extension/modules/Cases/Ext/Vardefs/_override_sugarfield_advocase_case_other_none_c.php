<?php
 // created: 2024-05-18 00:27:12
$dictionary['Case']['fields']['advocase_case_other_none_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_case_other_none_c']['labelValue']='Other/None';

 ?>