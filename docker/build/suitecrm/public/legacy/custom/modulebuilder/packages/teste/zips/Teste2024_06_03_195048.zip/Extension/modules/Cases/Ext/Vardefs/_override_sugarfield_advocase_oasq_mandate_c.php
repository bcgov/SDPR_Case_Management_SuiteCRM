<?php
 // created: 2024-05-21 19:55:50
$dictionary['Case']['fields']['advocase_oasq_mandate_c']['inline_edit']='1';
$dictionary['Case']['fields']['advocase_oasq_mandate_c']['labelValue']='Within OASQ mandate';

 ?>