<?php
$popupMeta = 
array (
  'moduleMain' => 'Meetings',
  'varName' => 'Meeting',
  'orderBy' => 'meetings.name',
  'whereClauses' => 
  array (
    'name' => 'meetings.name',
  ),
  'searchInputs' => 
  array (
    0 => 'meetings_number',
    1 => 'name',
    2 => 'priority',
    3 => 'status',
  ),
);
;
?>
