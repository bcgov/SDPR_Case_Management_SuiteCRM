<?php
 // created: 2024-05-16 22:45:24
$dictionary['Meeting']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>