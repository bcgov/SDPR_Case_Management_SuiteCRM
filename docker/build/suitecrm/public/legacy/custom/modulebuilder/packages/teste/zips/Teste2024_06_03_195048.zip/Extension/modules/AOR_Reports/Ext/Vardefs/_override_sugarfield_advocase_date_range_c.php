<?php
 // created: 2024-05-24 16:44:55
$dictionary['AOR_Report']['fields']['advocase_date_range_c']['inline_edit']='1';
$dictionary['AOR_Report']['fields']['advocase_date_range_c']['labelValue']='Time period';

 ?>