<?php
 // created: 2024-05-21 22:12:09
$dictionary['Call']['fields']['advocase_communication_date_c']['inline_edit']='1';
$dictionary['Call']['fields']['advocase_communication_date_c']['labelValue']='Date of Communication';

 ?>