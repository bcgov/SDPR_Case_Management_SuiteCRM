<?php
 // created: 2024-05-31 19:06:13
$dictionary['Meeting']['fields']['advocase_other_comm_c']['inline_edit']='1';
$dictionary['Meeting']['fields']['advocase_other_comm_c']['labelValue']='Other type';

 ?>