<?php

$app_strings['LBL_SUBTHEME_OPTIONS_BC_GOV'] = 'BC Gov';